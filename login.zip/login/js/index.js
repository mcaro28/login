/* $('.toggle').on('click', function() {
  $('.container').stop().addClass('active');
});

$('.close').on('click', function() {
  $('.container').stop().removeClass('active');
});

 */
(function () {
  document.getElementById('toggle').addEventListener('click', function () {
    document.getElementById('container').classList.toggle('active');
  });
  document.getElementById('close').addEventListener('click', function () {
    document.getElementById('container').classList.toggle('active');
  });
})()

